package net.minecraftforge.fml.common.eventhandler;



public interface IEventListener
{
    public void invoke(Event event);
}
