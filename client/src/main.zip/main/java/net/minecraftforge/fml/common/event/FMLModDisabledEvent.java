package net.minecraftforge.fml.common.event;

public class FMLModDisabledEvent extends FMLEvent {
}
