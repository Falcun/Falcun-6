package net.minecraftforge.fml.common;

public interface FMLContainerHolder
{
    ModContainer getFMLContainer();
}
