package falcun.net.dangui.util;

public final class Create {

}
