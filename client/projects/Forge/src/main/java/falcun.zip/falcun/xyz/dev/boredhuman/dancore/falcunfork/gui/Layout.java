package falcun.xyz.dev.boredhuman.dancore.falcunfork.gui;

public enum Layout {
	INLINE, BLOCK;
}