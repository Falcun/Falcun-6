package falcun.net.api.modules.throwables;

public class FinalFalcunSettingException extends Exception {
	public FinalFalcunSettingException(String message){
		super(message);
	}
}
