package falcun.net.z.optimizations;

public class EmptyClassDontTouch {
}
