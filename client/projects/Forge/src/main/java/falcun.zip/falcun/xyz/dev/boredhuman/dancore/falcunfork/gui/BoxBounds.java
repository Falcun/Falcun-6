package falcun.xyz.dev.boredhuman.dancore.falcunfork.gui;

public class BoxBounds {
	public int x, y, width, height;

	public BoxBounds() {

	}

	public BoxBounds(int x, int y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
}