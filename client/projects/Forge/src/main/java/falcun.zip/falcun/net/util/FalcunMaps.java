package falcun.net.util;

public class FalcunMaps {
}
