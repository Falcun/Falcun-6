package falcun.net.cosmetics;

public enum CosmeticType {
	CLOAK, BANDANA, WINGS, TAG, EARS, EMOTE,
	;
}
