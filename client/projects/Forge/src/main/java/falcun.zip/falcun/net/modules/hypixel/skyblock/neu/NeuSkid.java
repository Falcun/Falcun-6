package falcun.net.modules.hypixel.skyblock.neu;

public class NeuSkid {
}
