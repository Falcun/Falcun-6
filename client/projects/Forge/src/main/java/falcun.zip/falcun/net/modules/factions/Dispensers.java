package falcun.net.modules.factions;

import falcun.net.api.modules.FalcunModule;
import falcun.net.api.modules.config.FalcunModuleInfo;
import falcun.net.modules.ModuleCategory;

@FalcunModuleInfo(fileName = "Dispensers", name = "Dispensers", description = "Dispensers", version = "1.0.0", category = ModuleCategory.FACS)
public class Dispensers extends FalcunModule {
}
