package falcun.xyz.dev.boredhuman.dancore.falcunfork.gui.util;

public final class Alignment {
	public enum Horizontal {
		LEFT, CENTER, RIGHT;
	}

	public enum Vertical {
		TOP, CENTER, BOTTOM;
	}
}