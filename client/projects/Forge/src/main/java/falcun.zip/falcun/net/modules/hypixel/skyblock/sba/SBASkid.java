package falcun.net.modules.hypixel.skyblock.sba;

public class SBASkid {
}
