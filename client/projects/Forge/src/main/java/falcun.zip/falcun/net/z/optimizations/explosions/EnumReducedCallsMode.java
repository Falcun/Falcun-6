package falcun.net.z.optimizations.explosions;

public enum EnumReducedCallsMode {
	DISABLED,
	NEARBY,
	BOUNDS,
	TUNNELLING;
}
