package falcun.net.api.dangui.pages;

public interface FalcunCustomDimensionsGuiPage extends FalcunGuiPage{
}
