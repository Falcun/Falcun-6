package falcun.net.api.gui.inheritance;

public interface MinecraftMenuReplacementGui {
}
