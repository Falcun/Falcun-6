package falcun.net.fps;

public final class LightManager {
	public static boolean isRemoveLightCalculations(){
		return false;
	}
}
