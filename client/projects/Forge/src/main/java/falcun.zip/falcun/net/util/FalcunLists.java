package falcun.net.util;

import falcun.xyz.dev.boredhuman.dancore.falcunfork.util.Position;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.item.EntityTNTPrimed;

import java.util.List;

public class FalcunLists {
	public static List<EntityTNTPrimed> tnt = new ObjectArrayList<>();
	public static List<EntityFallingBlock> sand = new ObjectArrayList<>();
	public static List<Position> explosions = new ObjectArrayList<>();
}
