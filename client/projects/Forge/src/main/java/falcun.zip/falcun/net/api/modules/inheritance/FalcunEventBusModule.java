package falcun.net.api.modules.inheritance;

public interface FalcunEventBusModule {

	default void IGNORE_THIS_METHOD(){};
}
