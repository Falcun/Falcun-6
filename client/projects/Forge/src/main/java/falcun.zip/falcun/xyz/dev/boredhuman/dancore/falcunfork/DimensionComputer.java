package falcun.xyz.dev.boredhuman.dancore.falcunfork;

import falcun.xyz.dev.boredhuman.dancore.falcunfork.gui.elements.BasicElement;

public interface DimensionComputer {

	void computeChildBounds(BasicElement<?> element);
}