package falcun.net.modules.factions;

import falcun.net.api.modules.FalcunModule;
import falcun.net.api.modules.config.FalcunModuleInfo;
import falcun.net.modules.ModuleCategory;

@FalcunModuleInfo(fileName = "CaneHelper", name = "Cane Helper", description = "CaneHelper", version = "1.0.0", category = ModuleCategory.FACS)
public class CaneHelper extends FalcunModule {
}
