package mchorse.emoticons.capabilities.cosmetic;

/**
 * Cosmetic mode which identifies how to handle emoting
 */
public enum CosmeticMode
{
    CLIENT, PLUGIN, SERVER;
}
