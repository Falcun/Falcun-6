package falcun.net.util;

public class FalcunLists {
}
