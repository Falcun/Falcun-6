package falcun.net.gui.settings;

import falcun.net.api.gui.components.Component;
import falcun.net.api.gui.menu.FalcunMenu;

import java.util.List;

public final class FalcunSettingsMenu extends FalcunMenu {
	enum Page {

	}

	@Override
	public List<Component> getComponents() {
		return null;
	}

	@Override
	protected void init() {

	}
}
