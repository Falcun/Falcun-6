package falcun.net.api.gui.inheritance;

public interface NonBlurGui {
}
