package falcun.net.api.modules.inheritance;

public abstract class FalcunHudModule {
}
