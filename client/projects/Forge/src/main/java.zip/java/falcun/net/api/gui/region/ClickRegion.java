package falcun.net.api.gui.region;

public class ClickRegion extends GuiRegion{
	public ClickRegion(int x, int y, int width, int height) {
		super(x, y, width, height);
	}
}
