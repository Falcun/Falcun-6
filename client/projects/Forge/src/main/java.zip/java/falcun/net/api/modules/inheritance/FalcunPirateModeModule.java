package falcun.net.api.modules.inheritance;

public interface FalcunPirateModeModule {
}
