package falcun.net.managers;

public final class FalcunFPSManager {
	public static FalcunFPSManager falcunFPSManager = new FalcunFPSManager();



	FalcunFPSManager() {

	}

	public static void init() {

	}

}
