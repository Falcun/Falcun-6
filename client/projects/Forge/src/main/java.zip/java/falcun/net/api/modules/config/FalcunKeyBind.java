package falcun.net.api.modules.config;

import java.io.Serializable;

public class FalcunKeyBind implements Serializable {
}
