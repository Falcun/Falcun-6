package net.mattbenson.cosmetics.cape;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.NoSuchElementException;

import org.json.JSONException;

import net.mattbenson.Falcun;
import net.mattbenson.requests.ContentType;
import net.mattbenson.requests.WebRequest;
import net.mattbenson.requests.WebRequestResult;
import net.minecraft.client.Minecraft;

public class CapeLookupThread extends Thread {
	CapeManager capeManager;
	WebRequest request;
	
	public CapeLookupThread(CapeManager capeManager) {
		this.capeManager = capeManager;
		
		try {
			request = new WebRequest("https://falcun.net/old/refreshlist.txt", "GET", ContentType.NONE, false);
		} catch (JSONException | NoSuchElementException | IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {

		while (true) {
			if (capeManager != null && capeManager.getSettings().getEnabled()) {
				if (Minecraft.getMinecraft() != null && Minecraft.getMinecraft().theWorld != null
						&& Minecraft.getMinecraft().thePlayer != null) {
					performUpdate();
				}
			}
			try {
				CapeLookupThread.sleep(15 * 1000);
			} catch (InterruptedException interruptedexception) {
				interruptedexception.printStackTrace();
			}
		}
	}
	
	public void performUpdate() {
		try {
			WebRequestResult result = request.connect();
			
			String med = result.getData();
			
			if (!med.isEmpty()) {
				String[] splitOne = med.split("\\s*,\\s*");
				capeManager.getUserCapes().clear();
				for (String s : splitOne) {
					String[] split = s.split(":");
					String uuid = split[0];
					int capeID = Integer.parseInt(split[1]);
					capeManager.getUserCapes().put(uuid, capeID);
				}
			}
		} catch (JSONException | NoSuchElementException | IOException | ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}

	}
}
